#!/bin/sh

mkdir /usr/local/lib/sdfcli
cp /usr/local/Cellar/sdfcli/17.2.0/* /usr/local/lib/sdfcli
mv /usr/local/lib/sdfcli/sdfcli /usr/local/bin